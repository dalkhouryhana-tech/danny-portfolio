# Danny — Applications Developer Portfolio

A single self-contained HTML file. No build step, no server, no database, no API keys.

## What's in this folder
- `index.html` — the entire website: HTML, CSS, and JavaScript in one file.
  Your logo (nav mark + full-page background), all project screenshots, and
  the About Me / contact sections are embedded directly in the file — no
  separate image files to keep track of or lose.

## External dependencies (both load automatically, no setup needed)
- Google Fonts (Space Grotesk, Inter, IBM Plex Mono, Tajawal) — loaded via
  `<link>` tags in the `<head>`.
- Nothing else. No frameworks, no npm packages, no backend, no Claude/Anthropic
  services of any kind. The English/Arabic toggle and language memory run on
  plain browser localStorage, which works identically on any domain.

## How to deploy (pick one — all are free, all give you your own URL)

### Option A — Netlify (easiest, drag-and-drop)
1. Go to https://app.netlify.com/drop
2. Drag this folder onto the page.
3. Netlify gives you a live URL immediately (e.g. `your-site.netlify.app`).
4. Add a custom domain later under Site settings → Domain management, if you
   want something like `dannydev.com` instead.

### Option B — Vercel
1. Create a free account at https://vercel.com
2. Install the CLI: `npm i -g vercel`
3. From inside this folder, run `vercel` and follow the prompts.
4. Vercel gives you a URL like `your-site.vercel.app`, with custom domains
   supported free.

### Option C — GitHub Pages
1. Create a new GitHub repository and push this folder's contents to it.
2. In the repo: Settings → Pages → Source → deploy from the `main` branch, root folder.
3. Your site is live at `https://<your-username>.github.io/<repo-name>`.
4. A custom domain can be attached under the same Pages settings.

### Option D — Cloudflare Pages
1. Create a free account at https://pages.cloudflare.com
2. Connect a GitHub repo (or use direct upload) and point it at this folder.
3. You get a `your-site.pages.dev` URL, with free custom domain support.

## Custom domain (optional, works with any option above)
Buy a domain from any registrar (Namecheap, Google Domains, GoDaddy, etc.),
then follow the host's "custom domain" instructions to point it at your new
site. This gives you a URL like `www.dannydev.com` with no Claude, Netlify,
or Vercel branding in it at all.

## Updating the site later
Just edit `index.html` directly (or ask Claude to make changes and re-export),
then re-upload/re-deploy using whichever option you picked above.
